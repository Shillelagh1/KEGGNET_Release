Hello.
The following instructions will allow you to setup the KEGGNET interface fairly easily on your machine.
The instructions are intended for WINDOWS machines.

Step 1.) Network Setup:
->Open the windows search bar and type in "windows defender firewall" and open the program.
	(It should appear as a globe and brick wall)
->Click "Advanced Settings" on the left hand of the new window.
->Click "Inbound Rules" in the top left of the new window.
->Click "New Rule" on the right and side of the application.
	-> Select "Port". Next
	-> Select "TCP", "Specific Local Ports" and type the numbers "2334" in the text box.
	-> Next
	-> Select "Allow the connection". Next
	-> Select all the check boxes (you may revisit later). Next
	-> Give it a name like "KEGGNET" and click finish
->Exit the windows defenders firewall windows (You don't need them anymore)
->Open KeggNET.exe as administrator (right click)
	NOTE: You can use it as non administrator but you will not be able to:
		-Host
		-Use chat rooms

Proceed to the instructions below:

For Users (Not host):
->Ask for the server IP address and input it into the console. Be sure not to include any spaces.
->Await the connection established message.
->Create an account by typing "0" into the console.
->Be sure to read the on screen safety instructions.
->Enter username and password.
->Marvel.